public class DataTypes {
    public static void main(String[] args) {
        long number = 529999999999999999L;
        System.out.println("Number is : " + number);
        char letter = 'G';
        System.out.println("Letter is :" + letter);
        boolean isEligible = true;
        System.out.println("Is eligible :" + isEligible);
        float pi = 3.14f;
        System.out.println("PI is : " + pi);
        double money = 1234.56667d;
        System.out.println("Money is: " + money);
        byte test = 13;
        System.out.println("Byte test is : " + test);
    }
}



