public class RightTriangle {
    public static void main(String[] args) {
        int stars = 2;
        // int space = 0;
        // print the stars 
        int rows = 15;
        int cols = 15;
        // first row 
        System.out.println("*");
        // middle rows ( 1 => n - 1 )
        for (int row = 1; row < rows - 1; row++) {
            // first col
            System.out.print("*");
            // give spaces (middle cols) 
            for (int s = 0; s < row - 1; s++) {
                System.out.print(" ");
            }
            // space += 1;
            // last cols
            System.out.println("*");
            // System.out.println();
        }
        // last row
        for (int col = 0; col < cols; col++) {
            System.out.print("*");
        }
    }
}