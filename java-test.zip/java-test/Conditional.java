public class Conditional {
    public static void main(String[] args) {
        int age = -78;
        // if (age < 0) {
        //     System.out.println("Age cannot be negative .... , Please enter a positive number in range( 0 to 150)");
        // } else {
        //     if (age > 150) {
        //         System.out.println("Age cannot be greater than 150 .... , Please enter a positive number in range( 0 to 150)");
        //     } else {
        //         if (age >= 18) {
        //             System.out.println("Eligible to vote ... ");
        //         } else {
        //             System.out.println("Not Eligible to vote ... ");
        //         }
        //     }
        // }
        
        // if (age < 0) {
        //     System.out.println("Age cannot be negative .... , Please enter a positive number in range( 0 to 150)");
        // } else if (age > 150) {
        //     System.out.println("Age cannot be greater than 150 .... , Please enter a positive number in range( 0 to 150)");
        // } else if(age >= 18) {
        //     System.out.println("Eligible to vote ... ");
        // } else {
        //     System.out.println("Not eligible to vote .... ");
        // }


        if (age < 0 || age > 150) {
            System.out.println("Age cannot be negative .... or greater than 150 , Please enter a positive number in range( 0 to 150)");
        } else if(age >= 18) {
            System.out.println("Eligible to vote ... ");
        } else {
            System.out.println("Not eligible to vote .... ");
        }


    }
}
