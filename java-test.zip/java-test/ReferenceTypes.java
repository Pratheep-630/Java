import java.util.*;

public class ReferenceTypes {
    public static void main(String[] args) {
        // strings
        String username = "Ganesha";
        System.out.println("Username is : " + username);

        String productName = "Computer Science";
        System.out.println("ProductName is : " + productName);

        // arrays
        int[] numbers = {1,3,4,5,6};
        System.out.println("numbers :" + numbers);

        String[] usernames = {"Anil", "Ravi", "Sudheer"};
        System.out.println("usernames: " + usernames);

        // Array of chars 

        char[] characters = {'a', 'n', 'i', 'l'};

        float[] temperatureReadings = { 23.3f, 45.5f, 67.8f };

        int num = 200;
        System.out.println("num is: " + num);

        int num2 = num;
        System.out.println("num2 is : "  + num2);

        int[] numbers1 = {1,3,4,5,6};
        int[] numbers2 = numbers1;
        System.out.println("numbers1 : " + numbers1);
        System.out.println("numbers2 : " + numbers2);

        numbers1[1] = 1200;
        System.out.println(Arrays.toString(numbers1));
        System.out.println(Arrays.toString(numbers2));
        String hello = null;
        System.out.println("hello: " + hello);

    }

}
