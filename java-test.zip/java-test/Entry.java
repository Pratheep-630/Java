public class Entry {

    public static void main(String[] args) {
        // Person  p1 = new Person(20, 160, 7416751457l, 45f, "1-29", "tekumanda", 517429, "chittoor", "AP", "IND", "Manjunath");
        // p1.printInfo();
        // Person p2 = null;
        // p2.show();
        Student s1 = new Student(20, 160, 7416751457l, 45f, "1-29", "tekumanda", 517429, "chittoor", "AP", "IND", "Manjunath", "123", 7.9f, "CS", 'A');
        s1.printStudent();
    }
    
}

class Person {
    String name;
    int age;
    int height;
    long contact;
    float weight;
    Address address;

    Person(int age, int height, long contact, float weight, String doorNumber, String street, int pincode, String city, String state, String country, String name) {
        System.out.println("this : " + this);
        this.age = age;
        this.name = name;
        this.contact = contact;
        this.weight = weight;
        this.height = height;
        Address address1 = new Address(doorNumber, street, pincode, city, state, country);
        this.address =  address1;

    }

    public void show() {
        this.printInfo();
    }

    public void printInfo() {
        System.out.println("Name is: " + name);
        System.out.println("age is: " + age);
        System.out.println("weight is: " + weight);
        System.out.println("contact is: " + contact);
        System.out.println("height is : " + height);
        System.out.println("address is : " + address.state);
        System.out.println("street is: " + address.street);
        System.out.println("pincode is: " + address.pincode);
        System.out.println("city is: " + address.city);
        System.out.println("country: " + address.country);
    }
}

class Address {
    String doorNumber;
    String street;
    int pincode;
    String city;
    String state;
    String country;


    Address(String doorNumber, String street, int pincode, String city, String state, String country) {
        this.city = city;
        this.doorNumber = doorNumber;
        this.country = country;
        this.pincode = pincode;
        this.state = state;
        this.street = street;
    }
}


class Student extends Person {
    String rollNumber;
    float gpa;
    String branch;
    char section;

    public Student(int age, int height, long contact, float weight, String doorNumber, String street, int pincode, String city, String state, String country, String name, String rollNumber, float gpa, String branch, char section) {
        super(age, height, contact, weight, doorNumber, street, pincode, city, state, country, name);
        this.rollNumber = rollNumber;
        this.gpa = gpa;
        this.branch = branch;
        this.section = section;
    }
    public void printStudent() {
        super.printInfo();
        System.out.println("rollNumber is: " + this.rollNumber);
        System.out.println("gpa is: " + this.gpa);
        System.out.println("Branch is : " + branch);
        System.out.println("section is: " + section);
    }
}