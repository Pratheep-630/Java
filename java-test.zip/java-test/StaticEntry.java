public class StaticEntry {
    public static void main(String[] args) {
        Person p1 = new Person("Anil", 24);
        Person p2 = new Person("Aravind", 25);
        System.out.println("p1: " + p1);
        System.out.println("p1.name : " + p1.name);
        System.out.println("p1.noOfEyes: " + p1.noOfEyes);
        // Person.noOfEyes = 2;
        // System.out.println("Person.noOfEyes " + Person.noOfEyes);
        p1.noOfEyes = 100;
        System.out.println("p1.noOfEyes" + p1.noOfEyes);
        System.out.println("p2.noOfEyes: " + p2.noOfEyes);
        Person.test();

    }
}


class Person {
    // instance attributes
    String name;
    int age;
    // class attribute
    static int noOfEyes;
    // constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
        // Person.noOfEyes = 2;
    }

    public static void test() {
        System.out.println("This is to test static method .. ");
        // System.out.println(this.name);
    }
}


class Student {
    
}