public class Rhombus {
    public static void main(String[] args) {
        // row and cols
        // int rows = 21;
        // int cols = 21;
        // int spaces = 1;
        // int frontSpaces = (cols / 2) - 1;
        // if (rows % 2 == 0 || cols % 2 == 0) {
        //     System.out.println("Cannot print a rhombus ....");
        //     return;
        // }
        // // first row ... 
        // for (int s = 0; s < (cols / 2); s++) {
        //     System.out.print(" ");
        // }
        // System.out.println("*");
        // // middle rows... 
        // for (int row = 1; row <= (rows / 2); row++) {
        //     // print front spaces
        //     for (int s = 0; s < frontSpaces; s++) {
        //         System.out.print(" ");
        //     }
        //     frontSpaces -= 1;
        //     // first col
        //     System.out.print("*");
        //     // middle 
        //     for (int s = 0; s < spaces; s++) {
        //         System.out.print(" ");
        //     }
        //     // last col
        //     System.out.print("*");
        //     System.out.println();
        //     spaces += 2;
        // }
        // // reverse pattern ...
        // int reversedFrontSpaces = 1;
        // int reversedSpaces = cols - 4;
        // for (int row = (rows / 2 + 1); row < rows - 1; row++) {
        //     // print front spaces
        //     for (int s = 0; s < reversedFrontSpaces; s++) {
        //         System.out.print(" ");
        //     }
        //     reversedFrontSpaces += 1;
        //     // first col
        //     System.out.print("*");
        //     // middle 
        //     for (int s = 0; s < reversedSpaces; s++) {
        //         System.out.print(" ");
        //     }
        //     // last col
        //     System.out.print("*");
        //     System.out.println();
        //     reversedSpaces -= 2;
        // }
        // last row ...
        // for (int s = 0; s < (cols / 2); s++) {
        //     System.out.print(" ");
        // }
        // System.out.println("*");

        int rows = 19;
        int cols = 19;
        // printing rhombus using maths equations and better version of above program
        for (int row = 0; row < rows; row++) {
            // left spaces 
            // cols / 2 - row
            // left spaces 
            for (int s = 0; s < Math.abs((cols / 2 - row)); s++) {
                System.out.print(" ");
            }
            // first star in row
            System.out.print("*");
            if (row == 0 || row == rows - 1) {
                System.out.println();
                continue;
            }
            // middle spaces in the row 
            // 2n - 1
            int mid = rows / 2;
            int r = row;
            if (row > mid) {
                r = rows - 1 - row;
            }
          
            for (int s = 0; s < (2 * r - 1); s++) {
                System.out.print(" ");
            }
            
            // last star in row 
            System.out.print("*");
            System.out.println();
        }
    }
}
