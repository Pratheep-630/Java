public class Loops {
    public static void main(String[] args) {
        long count = 1;
        // for (int num = 1; num <= count; num++) {
        //     System.out.println(num);
        // }

        // while (count <= 100) {
        //     System.out.println(count);
        //     count += 1;
        // }


        // do  - while

        // do {
        //     System.out.println(count);
        //     count += 1;
        // } while (false);


     
        
        for (int num = 0; num <= 100; num++) {
            if (num % 2 != 0) {
                continue;
            }
            System.out.println(num);
        }


    }
}
