public class ConstructorEntry {
    public static void main(String[] args) {
        Student s1 = new Student();
        Student s2 = new Student("Anil", 23, "2324", 8.0f);
        System.out.println("s1 : " + s1);
        System.out.println("s1.name: " + s1.name);
        System.out.println("s2: " + s2);
        System.out.println("s2.name :, s2.age " + s2.name + "    " + s2.age);
    }
}


class Student {
    String name;
    int age;
    String rollNumber;
    float gpa;

    public Student() {}

    public Student(String name, int age, String rollNumber, float gpa) {
        this.age = age;
        this.name = name;
        this.rollNumber = rollNumber;
        this.gpa = gpa;
    }
}
