import java.util.Arrays;

public class Oops {
    public static void main(String[] args) {
        int res = add(2, 5);
        System.out.println("Res is: " + res);
        int res1 = add(1000, 4500);
        System.out.println("res1: " + res1);
        String username = "Ganesha ... ";
        printUserName(username);
        System.out.println("inside main: " + username);
        int[] numbers = { 1, 2, 3, 4, 5 };
        printArray(numbers);
        System.out.println("inside main: " + Arrays.toString(numbers));
    }

    public static void printArray(int[] nums) {
        // for (int i = 0; i < nums.length; i++) {
        //     System.out.println("Number is: " + nums[i]);
        // }
        nums[1] = 12000;
        // for (int num : nums) {
        //     System.out.println("Number is: " + num);
        // }
    }
    
    public static int add(int n1, int n2) {
        int res = n1 + n2;
        return res;
    }

    public static void printUserName(String username) {
        System.out.println("Username is: " + username);
        username = "Anil .... ";
        System.out.println("Inside printUserName , after updating : " + username);
    }


}
