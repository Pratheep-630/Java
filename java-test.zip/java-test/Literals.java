public class Literals {
    String name = "Ganesha ... ";
    int n = 90;
    char c = 'A';
    float f = 78.78f;
}
