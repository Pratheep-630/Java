public class Scope {

    public static String data = "This is inside of class ... ";
    public static void main(String[] args) {
        int num = 10;
        System.out.println("Num is: " + num);
        String data1 = "This is inside of class ... ";
        {
            String name = "Inside of inner scope";
            num = 2344;
            System.out.println(data);
            System.out.println(num);
        }
        System.out.println("num is : " + num);
        // System.out.println("name is : " + name);
    }

    public static void test() {
        System.out.println("data is : " + data);
    }
}
